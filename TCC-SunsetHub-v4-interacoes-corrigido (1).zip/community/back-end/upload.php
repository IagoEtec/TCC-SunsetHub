<?php
declare(strict_types=1);

final class SunsetUploadException extends RuntimeException {}

/** Retorna um arquivo enviado ou uma mensagem de validação específica. */
function api_file_field(string $field): array
{
    $file = $_FILES[$field] ?? null;
    if (!is_array($file)) {
        throw new SunsetUploadException('Selecione o arquivo obrigatório para continuar.');
    }

    $error = (int)($file['error'] ?? UPLOAD_ERR_NO_FILE);
    if ($error !== UPLOAD_ERR_OK) {
        $messages = [
            UPLOAD_ERR_INI_SIZE => 'O arquivo excede o limite configurado pelo PHP. Use um arquivo de até 100 MB ou ajuste upload_max_filesize no php.ini.',
            UPLOAD_ERR_FORM_SIZE => 'O arquivo excede o limite permitido pelo formulário.',
            UPLOAD_ERR_PARTIAL => 'O upload foi interrompido. Tente enviar o arquivo novamente.',
            UPLOAD_ERR_NO_FILE => 'Selecione um arquivo para continuar.',
            UPLOAD_ERR_NO_TMP_DIR => 'A pasta temporária de upload do PHP não está disponível.',
            UPLOAD_ERR_CANT_WRITE => 'O servidor não conseguiu gravar o arquivo enviado.',
            UPLOAD_ERR_EXTENSION => 'Uma extensão do PHP bloqueou o upload do arquivo.',
        ];
        throw new SunsetUploadException($messages[$error] ?? 'Falha ao receber o arquivo enviado.');
    }
    if (empty($file['tmp_name']) || !is_uploaded_file((string)$file['tmp_name'])) {
        throw new SunsetUploadException('O arquivo enviado não pôde ser validado pelo servidor.');
    }
    return $file;
}

/** Armazena uma imagem ou vídeo com nome aleatório e validação MIME. */
function api_store_upload(array $file, string $folder, string $kind): string
{
    $tmp = (string)($file['tmp_name'] ?? '');
    $size = (int)($file['size'] ?? 0);
    if ($tmp === '' || !is_uploaded_file($tmp) || $size <= 0) {
        throw new SunsetUploadException('O arquivo enviado é inválido ou está vazio.');
    }

    $isVideo = $kind === 'video';
    $maxBytes = $isVideo ? 100 * 1024 * 1024 : 8 * 1024 * 1024;
    if ($size > $maxBytes) {
        throw new SunsetUploadException($isVideo ? 'Vídeos maiores que 100 MB não são aceitos.' : 'Imagens maiores que 8 MB não são aceitas.');
    }

    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($tmp);
    $extensions = $isVideo
        ? ['video/mp4' => 'mp4', 'application/mp4' => 'mp4']
        : ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    if (!isset($extensions[$mime])) {
        throw new SunsetUploadException($isVideo ? 'Envie um vídeo no formato MP4.' : 'Envie uma imagem JPG, PNG ou WebP.');
    }

    $allowedFolders = ['videos', 'thumbs', 'social', 'stories', 'groups', 'chat'];
    if (!in_array($folder, $allowedFolders, true)) {
        throw new SunsetUploadException('Destino de upload inválido.');
    }
    $base = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'uploads';
    $destinationDir = $base . DIRECTORY_SEPARATOR . $folder;
    if (!is_dir($destinationDir) && !mkdir($destinationDir, 0775, true) && !is_dir($destinationDir)) {
        throw new SunsetUploadException('O servidor não conseguiu criar a pasta de uploads.');
    }
    if (!is_writable($destinationDir)) {
        throw new SunsetUploadException('A pasta de uploads não tem permissão de escrita.');
    }

    try {
        $name = bin2hex(random_bytes(18)) . '.' . $extensions[$mime];
    } catch (Throwable $e) {
        throw new SunsetUploadException('Não foi possível gerar o nome seguro do arquivo.');
    }
    $relative = 'uploads/' . $folder . '/' . $name;
    $destination = $destinationDir . DIRECTORY_SEPARATOR . $name;
    if (!move_uploaded_file($tmp, $destination)) {
        throw new SunsetUploadException('O servidor não conseguiu salvar o arquivo. Verifique a permissão da pasta community/uploads.');
    }
    return $relative;
}

function api_delete_stored(?string $relative): void
{
    if (!$relative || !preg_match('~^uploads/(videos|thumbs|social|stories|groups|chat)/[a-f0-9]{36}\.(mp4|jpg|png|webp)$~D', $relative)) return;
    $file = dirname(__DIR__) . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relative);
    if (is_file($file)) @unlink($file);
}
